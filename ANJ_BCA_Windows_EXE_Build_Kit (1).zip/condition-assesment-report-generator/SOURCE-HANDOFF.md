# Source handoff

Condition Assessment Report Generator, version 1.17.4.
Source commit: cb4d3f9cd255d3c3cecf3e55fcd83ed58b5e24c9.

The original source files are unchanged. This ZIP includes application source,
assets, database schema and seed data, dependency manifests and lockfile,
build/deployment configuration, documentation, tests, sample spreadsheets,
and the vendored SheetJS tarball required by npm install.

## Install and run

Follow README.md for prerequisites and platform-specific details. From this folder:

```sh
npm ci
npm start
```

## AI configuration

Live credentials are intentionally omitted, including .env and the encrypted
src/ai/openrouter-secret.json file. Copy .env.example to .env, set your own
OPENROUTER_API_KEY, then run:

```sh
npm run encrypt-openrouter-key
```

Startup and package/make also generate the encrypted file when a key is configured.
AI features require this setup. Keep .env and the generated credential file private.

## Tests

Some tests inspect the Git index, and one expects the generated AI credential file
to exist. To run the complete suite from this source-only ZIP, initialize and stage
a local Git repository BEFORE generating the credential file:

```sh
git init
git add .
```

Then configure AI as above and run npm test. Do not stage or share the generated
credential file. The sample workbook used by data checks and import/report tests
is included.

## Omitted to keep the handoff small

Installed dependencies, build output and installers, virtual environments,
Git history, local tool/cache/session files, local databases, Terraform provider
downloads/state/private variable files, and live credentials are excluded.
Large reference PDFs, screenshots, and mockup/report archives under samples/
are also excluded; documentation may still mention these reference materials.
Dependencies are restored by npm ci and build output by npm run package or
npm run make. See README.md and docs/ for the existing development instructions.
