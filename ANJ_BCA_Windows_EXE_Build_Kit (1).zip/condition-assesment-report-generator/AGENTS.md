# condition-assesment-report-generator

Electron desktop app for producing Building Condition Assessment (BCA/FCA) reports from a local SQLite database. Built with Electron Forge, better-sqlite3, and vanilla JS/HTML/CSS.

See `docs/` for implementation-accurate documentation.

**[`plan.md`](plan.md) is what is left to build.** Temporary Shares is retired
— do not rebuild the dashboard, the Share Viewer, `.carshare` packaging, or
the issuer-key path. See
[docs/temporary-shares-retired.md](docs/temporary-shares-retired.md).

`CLAUDE.md` is a symlink to this file.

## Development assumptions

- The app is under active development. There is no production user data and no legacy field values to preserve.
- **Schema migrations are supported, but never silent.** Databases record their schema version in `PRAGMA user_version`. On open, an older database stops startup and prompts the user, who chooses whether to upgrade; the pre-migration file is always copied to a `.bak` beside the live one. See [docs/database.md](docs/database.md).
- **Every `data/schema.sql` change needs a matching migration.** Bump `SCHEMA_VERSION` in `src/db.js` and append a step to `MIGRATIONS`. `test/db-migrations.test.js` fails if you skip this — it asserts that migrating the frozen `test/fixtures/schema/v1.sql` fixture produces exactly a freshly created database.
- UI and schema changes do not need backward-compatibility shims for pre-existing free-text values (e.g. constraining `condition_rating` to a dropdown does not require handling old arbitrary strings).
- Dev databases can be rebuilt at any time via `load-local-db.sh` / `data/dummy_data.sql`.
- App version is shown in the application Help menu and Settings → About (not on the home canvas), from `package.json` via `app.getVersion()`.
- **Bump `package.json` `version` in the same commit as any user-visible change** — a behaviour fix, a schema migration, an export/report change. Squirrel only pushes an update to existing installs when the version *increases*, so an unbumped fix is a fix the client can never receive. Bumping costs nothing and is not a release.
- **Never publish a release unless the user explicitly asks for one.** Bumping the version is routine; running **Release Desktop** is not. Do not dispatch it, and do not dispatch **Verify Desktop** on your own either — both bill runner minutes (the Windows leg at 2×). When a release is asked for, the order is fixed: Verify Desktop green on the release commit, *then* Release Desktop. See [docs/releasing.md](docs/releasing.md).
- AI uses OpenRouter (session key loaded at startup — no user unlock password). Photo captions use a vision model (`OPENROUTER_VISION_MODEL`); executive-summary section writing uses a separate text model (`OPENROUTER_SUMMARY_MODEL`, default DeepSeek V4 Pro). Put `OPENROUTER_API_KEY` in `.env`; the app (and package/make) auto-build `src/ai/openrouter-secret.json` as AES-GCM ciphertext under an app wrap secret (anti-scanner packaging, not access control). **Hard constraints on the distributed key:** no OpenRouter *management* key ever ships, and no user ever opens the OpenRouter dashboard — the included key carries a developer-set US$10/month cap (that cap is the safety bound), and exhaustion is handled by developer rotation (fresh capped key + version-bumped release). AI is included by default. See [docs/ai-photo-labels.md](docs/ai-photo-labels.md) and [docs/executive-summary.md](docs/executive-summary.md).
- **The summary model reasons, and reasoning stays on.** Do not disable or throttle reasoning on `OPENROUTER_SUMMARY_MODEL` to save tokens — if reasoning can't be made to work, switch models instead. OpenRouter bills reasoning against `max_tokens`, so `SUMMARY_MAX_TOKENS` must cover the thinking trace *plus* the prose; too small a budget returns an empty message rather than an error naming the budget. See [docs/executive-summary.md](docs/executive-summary.md).
- **Autosave + undo/redo is the intended editing model app-wide** (no Save buttons on forms; flush before Back; Ctrl/Cmd+Z / Shift+Z). See [docs/editing-model.md](docs/editing-model.md).
- **UI behaviour can be checked in the real app, not just asserted in unit tests.** `scripts/ui-driver.js` launches the app and drives it over CDP with no extra dependencies (`npm run verify:ui`). The renderer's CDP endpoint cannot reach Electron APIs, so `app`/`BrowserWindow`/`webContents` are driven in the main process over `--inspect`. See [docs/ui-driver.md](docs/ui-driver.md).
- **Every GitHub Actions workflow is manual kickoff only.** `workflow_dispatch` is the only trigger any workflow carries — no `push`, no `pull_request`, no `schedule`, no `release`. Nothing in this repo starts a runner by itself. Kick one off with **Actions → *workflow* → Run workflow** or `gh workflow run <file>`, and check it with `gh run list`/`gh run watch`. `test/workflows-manual-only.test.js` fails if an automatic trigger is added back. **The consequence is load-bearing: CI catches nothing on its own now.** Pushing does not verify anything, so anything that depends on a CI result is unproven until you dispatch the run yourself and read it. **The pre-release gate is `verify-desktop.yml` (Verify Desktop)** — a non-publishing Windows+Linux verification that must be dispatched on the release commit and come back green *before* Release Desktop; it does not start itself and Release Desktop does not start it (see [docs/releasing.md](docs/releasing.md)).

## Git workflow

- **Commit straight to `main`.** Single-developer repo — no feature branches, no PRs. Do not create a branch just because a change is non-trivial.
- **Push every commit as you make it.** A commit is not finished until it is on `origin/main` — do not leave `main` ahead of the remote and do not ask whether to push. Pushing is safe here precisely because nothing runs on it: every workflow is `workflow_dispatch` only, so a push starts no runner and bills nothing. Publishing a release is still a separate, explicit request.
