# Condition Assessment Report Generator

Electron desktop app for producing Building Condition Assessment (BCA/FCA) reports from a local SQLite database. All data stays on the user's machine. See [`docs/`](docs/) for implementation details.

## Requirements

[Node.js](https://nodejs.org/), a C++ toolchain (for `better-sqlite3`), and `sqlite3` CLI (for the dev DB loader).

## Install & run

```bash
npm install     # rebuilds native SQLite binding automatically
npm start       # electron-forge start with hot reload
npm test        # unit tests (node:test under Electron as Node)
```

See [`docs/dev-environment.md`](docs/dev-environment.md) for the test runner, packaged smoke test, and electron-stub pattern.

## Build

```bash
npm run package        # unpacked app bundle in out/
npm run make           # platform installer (Squirrel/Windows, zip/macOS+Linux)
npm run test:packaged  # smoke-test packaged app + clean asar
```

## Dev database

The app's DB lives at `~/.config/condition-assesment-report-generator/app.db` (Linux). The schema and Uniformat pricing seed automatically on first launch.

Rebuild it from repo files for manual testing:

```bash
./load-local-db.sh                          # default path
DB_PATH=/tmp/test.db ./load-local-db.sh     # custom path
```

Applies `data/schema.sql`, seeds `uniformat_pricing` from `data/uniformat_pricing.csv`, then loads `data/dummy_data.sql`. Requires `sqlite3` and `node`.

The pricing seeder can also be run standalone:

```bash
node scripts/write-uniformat-pricing-sql.js data/uniformat_pricing.csv | sqlite3 app.db
```

## Repo layout

```
src/        Main, preload, db, app-settings, undo-history, per-page renderers
src/lib/    Shared Node modules (csv-utils)
pages/      One HTML file per screen
styles/     CSS (one file per concern)
data/       schema.sql, dummy_data.sql, uniformat_pricing.csv
test/       Unit tests (*.test.js) and helpers/
scripts/    Dev CLI tools and test runner
samples/    Reference BCA reports and Uniformat level reference
docs/       Implementation documentation
```
