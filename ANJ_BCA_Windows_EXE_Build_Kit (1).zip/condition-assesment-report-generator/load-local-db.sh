#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
db_path="${DB_PATH:-${XDG_CONFIG_HOME:-$HOME/.config}/condition-assesment-report-generator/app.db}"

if ! command -v sqlite3 >/dev/null 2>&1; then
  printf 'sqlite3 is required but was not found in PATH.\n' >&2
  exit 1
fi

if [[ ! -f "$script_dir/data/schema.sql" ]]; then
  printf 'Missing schema file: %s\n' "$script_dir/data/schema.sql" >&2
  exit 1
fi

if [[ ! -f "$script_dir/data/dummy_data.sql" ]]; then
  printf 'Missing dummy data file: %s\n' "$script_dir/data/dummy_data.sql" >&2
  exit 1
fi

if [[ ! -f "$script_dir/data/uniformat_pricing.csv" ]]; then
  printf 'Missing Uniformat pricing file: %s\n' "$script_dir/data/uniformat_pricing.csv" >&2
  exit 1
fi

mkdir -p "$(dirname "$db_path")"
rm -f "$db_path"

sqlite3 "$db_path" <<SQL
.read '$script_dir/data/schema.sql'
SQL

node "$script_dir/scripts/write-uniformat-pricing-sql.js" "$script_dir/data/uniformat_pricing.csv" | sqlite3 "$db_path"

sqlite3 "$db_path" <<SQL
.read '$script_dir/data/dummy_data.sql'
SQL

printf 'Dropped and reloaded schema.sql, uniformat_pricing.csv, and dummy_data.sql into %s\n' "$db_path"
printf 'If the Electron app is already running, switch back to it — project data should appear automatically.\n'
printf 'If it does not, quit and restart the app (npm start).\n'
