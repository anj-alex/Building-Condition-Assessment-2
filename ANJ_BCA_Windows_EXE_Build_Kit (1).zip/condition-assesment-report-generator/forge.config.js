const path = require('node:path');
const { FusesPlugin } = require('@electron-forge/plugin-fuses');
const { FuseV1Options, FuseVersion } = require('@electron/fuses');

/** App icon without extension — packager appends .ico / .icns / .png per platform. */
const appIcon = path.resolve(__dirname, 'assets/icon');

/**
 * Paths electron-packager sees are app-root-relative and start with `/`.
 * Only runtime assets should ship: src/, pages/, styles/, assets/, data/schema.sql,
 * data/uniformat_pricing.csv, package.json, and production node_modules.
 */
const packagerIgnorePatterns = [
  // VCS / tooling / local env (never ship plaintext API keys)
  /^\/\.agents($|\/)/,
  /^\/\.git($|\/)/,
  /^\/\.github($|\/)/,
  /^\/\.venv($|\/)/,
  /^\/venv($|\/)/,
  /^\/\.gitignore$/,
  /^\/\.env$/,
  /^\/\.env\..+$/,
  // Dev docs and sample reference material
  /^\/docs($|\/)/,
  /^\/samples($|\/)/,
  /^\/AGENTS\.md$/,
  /^\/CLAUDE\.md$/,
  /^\/README\.md$/,
  // Tests, scripts, build output
  /^\/test($|\/)/,
  /^\/scripts($|\/)/,
  // Source tarballs are install inputs; the unpacked runtime dependency ships
  // from node_modules, so do not duplicate these bytes in the application.
  /^\/vendor($|\/)/,
  /^\/out($|\/)/,
  // Azure release infra — not needed at app runtime
  /^\/terraform($|\/)/,
  // Dev-only database seed (never ship sample firm/projects)
  /^\/data\/dummy_data\.sql$/,
  /^\/load-local-db\.sh$/,
  // Not needed at runtime
  /^\/package-lock\.json$/,
  /^\/forge\.config\.js$/,
];

module.exports = {
  packagerConfig: {
    asar: true,
    asarUnpack: '**/node_modules/better-sqlite3/**',
    ignore: packagerIgnorePatterns,
    // Embeds the platform icon into the packaged binary (exe resource on Windows).
    icon: appIcon,
  },
  rebuildConfig: {},
  makers: [
    {
      name: '@electron-forge/maker-squirrel',
      platforms: ['win32'],
      config: {
        // Installer + Start Menu shortcut glyph (Windows).
        setupIcon: path.resolve(__dirname, 'assets/icon.ico'),
      },
    },
    {
      name: '@electron-forge/maker-zip',
      platforms: ['darwin', 'linux'],
    },
  ],
  plugins: [
    {
      name: '@electron-forge/plugin-auto-unpack-natives',
      config: {},
    },
    // Fuses are used to enable/disable various Electron functionality
    // at package time, before code signing the application
    new FusesPlugin({
      version: FuseVersion.V1,
      [FuseV1Options.RunAsNode]: false,
      [FuseV1Options.EnableCookieEncryption]: true,
      [FuseV1Options.EnableNodeOptionsEnvironmentVariable]: false,
      [FuseV1Options.EnableNodeCliInspectArguments]: false,
      [FuseV1Options.EnableEmbeddedAsarIntegrityValidation]: true,
      [FuseV1Options.OnlyLoadAppFromAsar]: true,
    }),
  ],
};
