# Windows EXE build

This is a build-ready source package, **not an EXE**. It has not been built or tested on Windows.

1. Upload/commit the **contents** of the condition-assesment-report-generator folder to your GitHub repository, including `.github/workflows/build-anj-windows.yml`.
2. Open GitHub > Actions > Build ANJ BCA Windows Installer > Run workflow.
3. When the job succeeds, download the `ANJ-BCA-Manager-Windows-build` artifact. It contains the generated Windows installer.
4. Test on Windows using a copy of your data. Do not uninstall the original app until validated.

The current package metadata still identifies the original product/version 1.17.4. The new photo matcher is not yet wired into Excel import, and Word export is not verified repaired. This build is for testing, not a completed 2.0 release.
