# ANJ BCA Manager 2.0 — incremental upgrade (working source)

## Implemented in this iteration
- Word report screen now shows an explicit, accessible explanation next to the Save Word Report button when it is disabled, including whether preview generation, AI processing, or review validation is blocking export. This is a diagnostic usability repair, **not** a verified fix to the underlying export failure.
- Preserved the standalone photo filename matcher from the earlier working-source ZIP. It matches exact filenames case-insensitively, handles Windows paths and multiple references, and flags missing/ambiguous matches.

## Validation
- `node --check src/property-report.js`: passed.
- `node --test test/photo-filename-matcher.test.js`: 3 passed.
- Electron app and full DOCX export were **not** run here; dependencies and Windows runtime are not installed.

## Outstanding
- Connect Excel photo-reference columns to the workbook parser and photo storage, with user review before writes.
- Diagnose export in a running Windows app, fix root cause, and verify generated DOCX with photos.
- Produce and test a Windows installer.
