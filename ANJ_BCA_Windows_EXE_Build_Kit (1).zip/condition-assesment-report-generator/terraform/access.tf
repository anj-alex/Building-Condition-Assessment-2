# Identity / RBAC for the release storage account.
#
# Design choice: STORAGE ACCOUNT KEY auth (not Entra ID / OIDC).
# Why: the deploying user (`az login`) on this Azure for Students subscription
# is Owner on the subscription but has NO directory roles in the school tenant,
# so creating an Entra ID app registration (needed for OIDC federated identity)
# fails with "Insufficient privileges". Storage-account-key auth skips Entra ID
# entirely; the GitHub Actions workflow uploads using the account key, and you
# mint SAS download links locally via `az login` (user delegation) or the key.
#
# This file only needs to grant the deploying user data-plane rights on the
# storage account so the local SAS-link script works with `--auth-mode login`
# (user delegation SAS, no key handling). The storage account key itself is
# exported from `azurerm_storage_account.releases` and pushed to GitHub Actions
# as AZURE_STORAGE_KEY by secrets.tf.

data "azurerm_client_config" "current" {}

resource "azurerm_role_assignment" "owner_blob_contributor" {
  scope                = azurerm_storage_account.releases.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.azurerm_client_config.current.object_id
}