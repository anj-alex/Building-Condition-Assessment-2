# Azure release distribution (Terraform)

Provisions a **private** Blob Storage container + the Azure RBAC needed so that:

1. The Release Desktop GitHub Actions workflow can mirror release artifacts into
   the container using the storage account **key** (no Entra ID / OIDC).
2. You can mint **expiring SAS download links** for your users locally with
   `../scripts/azure-release-links.sh` using a real `az login` user session
   (user delegation SAS, no key handling).

## Why account-key auth, not Entra ID / OIDC

The OIDC (workload-federation) design would be nicer, but it needs an Entra ID
**app registration** in the tenant, which requires Application Administrator or
Global Administrator directory roles. The deploying user on this Azure for
Students subscription is **Owner on the subscription** but has no directory
roles on the school tenant, so app registration is blocked. Authenticating with
the storage account key skips Entra ID entirely and works with just the
subscription-level Owner role.

Trade-off: a long-lived storage account key lives in GitHub Actions secrets.
Rotate with `az storage account keys renew` then `terraform apply`.

## What this creates

| Resource | Purpose |
|---|---|
| `azurerm_resource_group.releases` | Holds the storage account. |
| `azurerm_storage_account.releases` | Private blob storage (TLS 1.2, LRS). |
| `azurerm_storage_container.releases` | Container with `container_access_type = private`. Artifacts stored as `<tag>/<file>`. |
| `azurerm_role_assignment.owner_blob_contributor` | Grants **you** (the `terraform apply` user) `Storage Blob Data Contributor` on the storage account, so the local SAS-link script can list blobs and request user-delegation SAS with `az login`. |
| `github_actions_secret.azure_storage_account` | Pushes `AZURE_STORAGE_ACCOUNT` to the GitHub repo for the workflow. |
| `github_actions_secret.azure_storage_container` | Pushes `AZURE_STORAGE_CONTAINER` to the GitHub repo for the workflow. |
| `github_actions_secret.azure_storage_key` | Pushes `AZURE_STORAGE_KEY` (the storage account's primary key) to the GitHub repo. The workflow uses this to authenticate blob uploads. |

> All `github_actions_secret` writes use the `integrations/github` Terraform
> provider and your provided GitHub PAT. No secret needs to be set by hand in
> the GitHub UI.

## One-time setup

1. **Install tools / log in** (once per machine):
   ```
   az login
   az account set --subscription "<your-subscription-name-or-id>"
   az account show --query "{name:name, id:id, state:state}" -o table
   ```
   and a [Terraform](https://developer.hashicorp.com/terraform/install) binary on PATH.
   Confirm your user has **Owner** (or at minimum Contributor + a role that
   grants `Microsoft.Authorization/roleAssignments/write` and data-plane:

2. **Create a GitHub PAT.** Classic token, check `repo` and `workflow` scopes
   (the `integrations/github` provider needs these to write Actions secrets on a
   private repo). Create at https://github.com/settings/tokens

3. **Configure values:**
   ```
   cp terraform.tfvars.example terraform.tfvars
   $EDITOR terraform.tfvars          # fill in github_token and azure_storage_account_name
   ```
   `azure_storage_account_name` must be **globally unique** across all of Azure
   (3–24 chars, lowercase letters/digits only). Prefix it with your initials.

4. **Init and apply:**
   ```
   terraform init
   terraform apply
   ```
   Review the plan, type `yes`. Terraform provisions the resources and publishes
   the three GitHub Actions secrets — nothing to paste in the GitHub UI.

## Day-to-day

- Trigger **Release Desktop** from Actions → Run workflow. After it succeeds,
  artifacts are in both the GitHub Release and `releases/<tag>/` in your Blob
  container.
- Generate user-facing download links:
  ```
  scripts/azure-release-links.sh                  # latest tag, 7-day link
  scripts/azure-release-links.sh v1.0.2           # a specific tag
  scripts/azure-release-links.sh v1.0.2 --days 30 --account-key   # >7d needs --account-key
  scripts/azure-release-links.sh v1.0.2 --exact '*.exe' --open
  ```
  Default mode uses **user delegation SAS** signed by your Entra ID session;
  after 7 days (Azure's hard cap) the link stops working, or sooner if you
  `az logout` / your session is revoked. `--account-key` lifts the cap to any
  `--days`.

## Notes & limitations

- **Single-developer, no remote backend.** State stays in `terraform.tfstate`
  locally (gitignored). To share or back up state, add a backend block
  (`azurerm` is the natural choice) to `main.tf` and run `terraform init -reconfigure`.
- **Storage account names are global.** A name conflict at apply time means
  someone else already owns it — pick another in `terraform.tfvars` and re-apply.
- **Mirror consistency.** Mirrored uploads come from the same `release-windows`
  and `release-linux` artifacts as the GitHub Release. If you re-create a
  GitHub Release you may want to clean up stale blobs in the container by hand.
- **Key rotation.** After `az storage account keys renew --account-name ... --key primary`,
  re-run `terraform apply` — the `github_actions_secret.azure_storage_key`
  resource will diff on the storage account's regenerated primary key and push
  the new value to GitHub.
- **Cost**: Standard LRS storage is a few cents/GB/month; downloads are billed
  per GB egress. Release artifacts for an Electron app are small, so this stays
  negligible.

## Destroy

```
terraform destroy
```
Removes the resource group (and storage account), the role assignment, and the
GitHub Actions secrets (the provider tracks them).