variable "github_token" {
  description = "GitHub PAT with `repo` and `workflow` scopes. Used only at apply time to write Actions secrets. Not stored anywhere."
  type        = string
  sensitive   = true
}

variable "github_repo_owner" {
  description = "GitHub account that owns the release repository."
  type        = string
  default     = "KianBahasadri"
}

variable "github_repo_name" {
  description = "GitHub repository name."
  type        = string
  default     = "condition-assesment-report-generator"
}

# Note: no azure_subscription_id variable — the azurerm provider uses the
# subscription that `az login` is currently scoped to (Owner on the
# "Azure for Students" sub, per `az account show`).

variable "azure_location" {
  description = "Azure region for the resource group and storage account."
  type        = string
  default     = "eastus"
}

variable "azure_resource_group_name" {
  description = "Name of the resource group that will hold the release storage account."
  type        = string
  default     = "rg-pcarelease"
}

variable "azure_storage_account_name" {
  description = "Globally unique storage account name (3-24 chars, lowercase letters/digits only)."
  type        = string
}

variable "azure_storage_container_name" {
  description = "Blob container that holds release artifacts, organized as `<tag>/<filename>`."
  type        = string
  default     = "releases"
}