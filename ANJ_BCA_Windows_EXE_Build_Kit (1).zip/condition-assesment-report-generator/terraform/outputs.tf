output "storage_account_name" {
  description = "Name of the storage account holding release artifacts."
  value       = azurerm_storage_account.releases.name
}

output "storage_container_name" {
  description = "Blob container name inside the storage account."
  value       = azurerm_storage_container.releases.name
}

output "storage_resource_group_name" {
  description = "Resource group holding the storage account."
  value       = azurerm_resource_group.releases.name
}

output "storage_account_key" {
  description = "Primary access key for the storage account. Pushed to GitHub Actions as AZURE_STORAGE_KEY; also usable by scripts/azure-release-links.sh --account-key."
  value       = azurerm_storage_account.releases.primary_access_key
  sensitive   = true
}