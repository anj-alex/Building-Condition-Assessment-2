# GitHub Actions repo secrets written by terraform at `apply` time.
#
# The Release Desktop workflow's `azure-upload` job uploads artifacts via the
# storage account KEY (not Entra ID / OIDC), because the deploying user cannot
# create an Entra ID app registration on this Azure for Students tenant. See
# access.tf for the rationale.
#
# Requires a GitHub PAT with `repo` + `workflow` scopes (classic) passed in
# var.github_token. The PAT is used only at apply time to push four secrets; it
# is never stored in state beyond the provider's transient auth.

resource "github_actions_secret" "azure_storage_account" {
  repository      = var.github_repo_name
  secret_name     = "AZURE_STORAGE_ACCOUNT"
  plaintext_value = azurerm_storage_account.releases.name
}

resource "github_actions_secret" "azure_storage_container" {
  repository      = var.github_repo_name
  secret_name     = "AZURE_STORAGE_CONTAINER"
  plaintext_value = azurerm_storage_container.releases.name
}

# The storage-account primary access key. Long-lived, but rotatable via
# `az storage account keys renew` (then `terraform apply` to refresh the secret).
# This is the trade-off of avoiding Entra ID app registrations: a shared key
# lives in GitHub Actions secrets instead of short-lived OIDC tokens.
resource "github_actions_secret" "azure_storage_key" {
  repository      = var.github_repo_name
  secret_name     = "AZURE_STORAGE_KEY"
  plaintext_value = azurerm_storage_account.releases.primary_access_key
}