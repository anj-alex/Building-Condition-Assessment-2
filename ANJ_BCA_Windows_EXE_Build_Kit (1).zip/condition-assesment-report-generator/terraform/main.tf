terraform {
  required_version = ">= 1.5"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
    github = {
      source  = "integrations/github"
      version = "~> 6.0"
    }
  }

  # Keep state local for this single-developer repo. If you want team sharing,
  # configure a remote backend in this block (azurerm or GCS) and run `terraform init -reconfigure`.
}

provider "azurerm" {
  features {}
}

provider "github" {
  owner = var.github_repo_owner
  token = var.github_token
}