# Storage account that holds release artifacts. Container organization: `<tag>/<file>`.
# Public blob access is disabled at the container level (`container_access_type = "private"`),
# so the only way to download is via the SAS URLs the bash script mints.

resource "azurerm_resource_group" "releases" {
  name     = var.azure_resource_group_name
  location = var.azure_location
}

resource "azurerm_storage_account" "releases" {
  name                     = var.azure_storage_account_name
  resource_group_name      = azurerm_resource_group.releases.name
  location                 = azurerm_resource_group.releases.location
  account_tier             = "Standard"
  account_replication_type = "LRS" # single-region; releases are reproducible, not critical data
  min_tls_version          = "TLS1_2"
}

resource "azurerm_storage_container" "releases" {
  name                  = var.azure_storage_container_name
  storage_account_name  = azurerm_storage_account.releases.name
  container_access_type = "private" # only SAS-authenticated requests can read blobs
}
