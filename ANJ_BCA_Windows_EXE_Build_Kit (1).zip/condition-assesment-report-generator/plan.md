# Plan — what is left to build

Forward-looking only. What is already built is documented in `docs/`.

Last revised 2026-08-16.

---

## Temporary Shares is retired

The desktop Temporary Shares product is gone. See
[docs/temporary-shares-retired.md](docs/temporary-shares-retired.md).

These remaining desktop-share items are **cancelled, not deferred**:

- Shipping the issuer key inside the operator app
- Spike 3 (by-hand SmartScreen / Mark-of-the-Web check)
- The by-hand adversarial checklist
- Re-issuing a share from returned work

Do not rebuild the dashboard, the Share Viewer, `.carshare` packaging, the
issuer-key path, or the Windows share gate.

## Future sharing

Sharing will be a website, where the operator has more control over delivery,
access, and expiry. That work is not started and has no leftover on the
desktop app. Do not invent a site design here.

This removal is not a release: do not bump `package.json` version and do not
publish an installer for it.

## Open: UI-driver scenarios lose their window intermittently (~1 run in 7)

Local-only so far, on the Linux dev box. Seen in three different scenarios and
three unrelated waits — `verify-excel-import` (property list after an import),
`verify-word-export` (same import), and `verify-asset-calculations` (a newly
opened asset form) — so it is **not** specific to the Excel import despite being
easiest to hit there.

**What it is not.** The import completes in the failing runs (the overlay names
every phase, 4,091 rows land), and the database work behind the refresh that
follows measures ~50 ms for all 26 buildings (`listBuildings` +
`listBuildingImages` + `getBuildingCapitalPlan`). Memory is not tight (~16 GB
available) and no Electron processes leak between runs. Two real concurrency
bugs *were* found while chasing it and are fixed — see
[docs/home-page.md](docs/home-page.md), `homeSyncToken` and `homeSyncRequest` —
but neither made it go away.

**What it looks like.** The document the scenario was driving is gone. The
in-page recorder installed before the click comes back empty
(`selectionTrace: []`) and the page reads exactly like a fresh bootstrap:
nothing selected, no property rows, the import button back to its original
label, no toast. One failure could not evaluate at all (`Runtime.evaluate timed
out after 60000ms`), which is what a torn-down execution context looks like.
Electron reports no `render-process-gone` and no `did-fail-load`, and nothing in
`src/` navigates on these paths.

Next step is to observe the replacement rather than infer it: subscribe to
`Page.frameNavigated` / `Runtime.executionContextDestroyed` on the CDP session
for the whole scenario and log them. `Cdp.until`'s `diagnose` argument already
reports `documentAgeMs` and `readyState` on timeout, so a future occurrence says
whether the document is new. Worth ruling out the local X/GPU stack first
(`vaInitialize failed` appears in every run's output, and the driver already
passes `--disable-gpu`) — CI has not shown this.

## Git workflow

**Commit straight to `main`.** Single-developer repo — no feature branches, no
PRs. Do not create a branch just because a change is non-trivial.
